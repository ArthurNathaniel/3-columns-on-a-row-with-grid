# 3 Column Responsive Layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/Cheesetoast/pen/kONLOM](https://codepen.io/Cheesetoast/pen/kONLOM).

At full width all three columns will be displayed side by side. As the page is resized the third column will collapse under the first and second. At the smallest screen size all three columns will be stacked on top of one another.
/*
Note: You can easily create additional columns by adding more elements with the class of 'column' inside the 'columns' div. e.g.:

...
<div class="column">
  <h2>4th column</h2>
</div>
<div class="column">
  <h2>5th column</h2>
</div>

*/